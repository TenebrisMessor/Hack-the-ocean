package com.aceanreport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AceanreportApplicationTests {

	@Test
	void contextLoads() {
	}

}
