package com.aceanreport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AceanreportApplication {

	public static void main(String[] args) {
		SpringApplication.run(AceanreportApplication.class, args);
	}

}